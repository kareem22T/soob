<?php

namespace App\Filament\User\Resources\UserCustomeRequestsResource\Pages;

use App\Filament\User\Resources\UserCustomeRequestsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUserCustomeRequests extends CreateRecord
{
    protected static string $resource = UserCustomeRequestsResource::class;
}
